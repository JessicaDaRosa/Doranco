/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.exercices_session1.Exercice1;

/**
 *
 * @author farouk228
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Point a = new Point(2,4);
       Point b = new Point(1,10);
       
       System.out.print("Ma distance entre le point a et b est de: " + b.distance(a));
    }
    
}

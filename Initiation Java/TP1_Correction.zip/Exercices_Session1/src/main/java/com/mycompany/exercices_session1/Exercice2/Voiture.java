/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercices_session1.Exercice2;

/**
 *
 * @author farouk228
 */
public class Voiture extends Vehicule{
    
    public Voiture(String categorie, String couleur) {
        super(categorie, couleur);
        this.nbreRoues = 4;
    }
    
}
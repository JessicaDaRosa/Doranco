/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercices_session1.Exercice2;

/**
 *
 * @author farouk228
 */
public class Vehicule {
    private String categorie;
    private String couleur;
    protected int nbreRoues;

    public Vehicule(String categorie, String couleur) {
        this.categorie = categorie;
        this.couleur = couleur;
    }

       
    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public String getCouleur() {
        return couleur;
    }

    public void setCouleur(String couleur) {
        this.couleur = couleur;
    }

    public int getNbreRoues() {
        return nbreRoues;
    }

    public void setNbreRoues(int nbreRoues) {
        this.nbreRoues = nbreRoues;
    }
    
}

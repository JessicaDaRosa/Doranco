/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labo08_12;

/**
 *
 * @author farouk228
 */
public abstract class Enseignant {
    // Déclaration de nos variables
    private String nom;
    private String prenoms;
    private int nbreHeures;
    
    /*
    Déclaration et Initialiation de la variable "nbreCharges" 
    puisqu'elle commune à tous les profils enseigants
    */
    static int nbreCharges = 1;

    
    // Constructeur de la classe
    public Enseignant(String nom, String prenoms, int nbreHeures) {
        this.nom = nom;
        this.prenoms = prenoms;
        this.nbreHeures = nbreHeures;
    }
   

    // Getters et Setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenoms() {
        return prenoms;
    }

    public void setPrenoms(String prenoms) {
        this.prenoms = prenoms;
    }

    public int getNbreHeures() {
        return nbreHeures;
    }

    public void setNbreHeures(int nbreHeures) {
        this.nbreHeures = nbreHeures;
    }
    
    // Signature de la fonction coutSalaire()
    public abstract float coutSalaire();
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labo08_12;

/**
 *
 * @author farouk228
 */
public class Doctorant extends Enseignant{

    public Doctorant(String nom, String prenoms, int nbreHeures) {
        super(nom, prenoms, nbreHeures);
    }

    @Override
    public float coutSalaire() {
        if(super.getNbreHeures() > 96){
            float salaire = (96 * 35) * nbreCharges;
            return salaire;
        }else{
            float salaire = (super.getNbreHeures() * 35) * nbreCharges;
            return salaire;
        }
    }
    
}

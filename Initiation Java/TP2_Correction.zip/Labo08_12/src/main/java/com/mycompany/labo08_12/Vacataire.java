/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labo08_12;

/**
 *
 * @author farouk228
 */
public class Vacataire extends Enseignant{
    private String organisme;

    public Vacataire(String nom, String prenoms, int nbreHeures) {
        super(nom, prenoms, nbreHeures);
    }

    public String getOrganisme() {
        return organisme;
    }

    public void setOrganisme(String organisme) {
        this.organisme = organisme;
    }

    @Override
    public float coutSalaire() {
        float salaire = (super.getNbreHeures() * 40) * nbreCharges;
        return salaire;
    }
    
    
}

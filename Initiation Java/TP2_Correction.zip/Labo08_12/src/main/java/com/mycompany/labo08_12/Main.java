/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.labo08_12;

/**
 *
 * @author farouk228
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        EnseignantChercheur ali = new EnseignantChercheur("BOUGA","Ali",200);
        System.out.println("Le salaire de Mr " + ali.getNom() + " " +
                ali.getPrenoms() + " est de: " + ali.coutSalaire() + " Euros");
        
        Doctorant martin = new Doctorant("ABBEY","Martin",65);
        System.out.println("Le salaire de Mr " + martin.getNom() + " " +
                martin.getPrenoms() + " est de: " + martin.coutSalaire() + " Euros");
    }
    
}

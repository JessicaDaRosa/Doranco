/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labo08_12;

/**
 *
 * @author farouk228
 */
public class EnseignantChercheur extends Enseignant{

    public EnseignantChercheur(String nom, String prenoms, int nbreHeures) {
        super(nom, prenoms, nbreHeures);
    }

    @Override
    public float coutSalaire() {
        float salaire = (2000*12 + (super.getNbreHeures() - 192)*40) * nbreCharges;
        
        return salaire;
    }
    
}
